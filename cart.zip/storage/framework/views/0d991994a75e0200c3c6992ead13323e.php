<?php
    $fieldValue = $values->where('custom_field_id', $field->id)->first()->value ?? null;
    $fieldId = 'field_' . $field->id;
?>



<div class="mb-3 ps-3 border-start dependent-field" 
     id="<?php echo e($fieldId); ?>" 
     data-parent="<?php echo e($field->parent_id); ?>" 
     data-show-if="<?php echo e($field->dependency_value); ?>" 
     style="<?php echo e($field->parent_id ? 'display:none;' : ''); ?>">

    <strong><?php echo e($field->label); ?></strong><br>

    <?php if($field->type === 'text'): ?>
        <input type="text"
       class="form-control"
       value="<?php echo e($fieldValue); ?>"
        name="custom[<?php echo e($field->id); ?>]"
       data-required="<?php echo e($field->required ? 'true' : 'false'); ?>"
       <?php echo e($field->parent_id ? '' : ($field->required ? 'required' : '')); ?>>


    <?php elseif($field->type === 'select'): ?>
        <select class="form-select"
        onchange="handleChange(this, '<?php echo e($field->id); ?>')"
        data-required="<?php echo e($field->required ? 'true' : 'false'); ?>"
        <?php echo e($field->parent_id ? '' : ($field->required ? 'required' : '')); ?>>
            <option value="">select  an option</option>
            <?php $__currentLoopData = explode(',', $field->options ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(trim($option)); ?>" <?php echo e(trim($option) == $fieldValue ? 'selected' : ''); ?>>
                    <?php echo e(trim($option)); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    <?php elseif($field->type === 'radio'): ?>
        <?php $__currentLoopData = explode(',', $field->options ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-check form-check-inline">
        <input type="radio"
               class="form-check-input readonly-radio"
               name="radio_<?php echo e($field->id); ?>"
               value="<?php echo e(trim($option)); ?>"
               <?php echo e(trim($option) == $fieldValue ? 'checked' : ''); ?>

               <?php echo e($field->required ? 'required' : ''); ?>

               onclick="handleRadioChange(<?php echo e($field->id); ?>, '<?php echo e(trim($option)); ?>')">
        <label class="form-check-label"><?php echo e(trim($option)); ?></label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php elseif($field->type === 'checkbox'): ?>
        <?php $selected = explode(',', $fieldValue); ?>
        <?php $__currentLoopData = explode(',', $field->options ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
                <input type="checkbox" class="form-check-input" disabled1 <?php echo e(in_array(trim($option), $selected) ? 'checked' : ''); ?> <?php echo e($field->required ? 'required' : ''); ?>>
                <label class="form-check-label"><?php echo e(trim($option)); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>


<?php if($field->children && $field->children->count()): ?>
    <?php $__currentLoopData = $field->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.field-display', ['field' => $child, 'values' => $values], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/partials/field-display.blade.php ENDPATH**/ ?>