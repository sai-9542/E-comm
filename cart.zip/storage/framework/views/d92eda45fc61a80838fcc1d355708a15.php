<?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-3">
        <label><?php echo e($field->label); ?></label>
        <?php if($field->type == 'text'): ?>
            <input type="text" name="custom[<?php echo e($field->id); ?>]" class="form-control">
        <?php elseif($field->type == 'select'): ?>
            <select name="custom[<?php echo e($field->id); ?>]" class="form-select">
                <?php $__currentLoopData = explode(',', $field->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(trim($option)); ?>"><?php echo e(trim($option)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php endif; ?>

        
        <?php $__currentLoopData = $field->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-2 ms-3 border-start ps-3">
                <label><?php echo e($child->label); ?></label>
                <?php if($child->type == 'text'): ?>
                    <input type="text" name="custom[<?php echo e($child->id); ?>]" class="form-control">
                <?php elseif($child->type == 'select'): ?>
                    <select name="custom[<?php echo e($child->id); ?>]" class="form-select">
                        <?php $__currentLoopData = explode(',', $child->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(trim($option)); ?>"><?php echo e(trim($option)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/partials/custom-field.blade.php ENDPATH**/ ?>