

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Your Cart</h2>

    <?php if(count($cart) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Custom Fields</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <tr>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['qty']); ?></td>
                        <td>
                            <?php $__currentLoopData = $item['custom_fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldId => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong><?php echo e($fieldMap[$fieldId] ?? 'Unknown'); ?></strong>: <?php echo e($value); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>
                        <td>
<a href="<?php echo e(route('cart.edit', $item['id'])); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('cart.destroy', $item['id'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/user/cart.blade.php ENDPATH**/ ?>