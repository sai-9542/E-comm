

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Cart Item</h2>

    <form action="<?php echo e(route('cart.update', $cart->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

        <?php $__currentLoopData = $product->customFields->whereNull('parent_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php echo $__env->make('cart.partials.field-edit', [
                'field' => $field,
                'fieldValues' => $fieldValues
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="btn btn-primary mt-3">Update Cart</button>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.dependent-field').forEach(function (childField) {
        const parentId = childField.dataset.parent;
        const expectedValue = childField.dataset.showIf;

        if (!parentId || !expectedValue) return;

        const parentField = document.querySelector(`#field_${parentId}`);
        if (!parentField) return;

        let parentValue = '';

        // Select
        const select = parentField.querySelector('select');
        if (select) parentValue = select.value;

        // Radio
        const radio = parentField.querySelector('input[type="radio"]:checked');
        if (radio) parentValue = radio.value;

        // Optional text
        const text = parentField.querySelector('input[type="text"]');
        if (text && !parentValue) parentValue = text.value;

        const shouldShow = parentValue === expectedValue;
        childField.style.display = shouldShow ? 'block' : 'none';

        childField.querySelectorAll('[data-required="true"]').forEach(input => {
            if (shouldShow) input.setAttribute('required', 'required');
            else input.removeAttribute('required');
        });
    });
});
</script>


<script>
function handleChange(el, fieldId) {
    const value = el.value;

    document.querySelectorAll('.dependent-field[data-parent="' + fieldId + '"]').forEach(child => {
        const expected = child.getAttribute('data-show-if');
        const shouldShow = value === expected;
        child.style.display = shouldShow ? 'block' : 'none';

        child.querySelectorAll('[data-required="true"]').forEach(input => {
            if (shouldShow) {
                input.setAttribute('required', 'required');
            } else {
                input.removeAttribute('required');
            }
        });
    });
}

function handleRadioChange(fieldId, selectedVal) {
    document.querySelectorAll(`.dependent-field[data-parent="${fieldId}"]`).forEach(child => {
        const expected = child.dataset.showIf;
        const isVisible = selectedVal === expected;

        child.style.display = isVisible ? 'block' : 'none';

        const radios = child.querySelectorAll('input[type="radio"]');
        if (radios.length > 0) {
            // Set required on first radio in the group
            if (isVisible) {
                radios[0].setAttribute('required', 'required');
            } else {
                radios[0].removeAttribute('required');
            }
        }

        const inputs = child.querySelectorAll('[data-required="true"]:not([type="radio"])');
        inputs.forEach(input => {
            if (isVisible) {
                input.setAttribute('required', 'required');
            } else {
                input.removeAttribute('required');
            }
        });
    });
}

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/cart/edit.blade.php ENDPATH**/ ?>